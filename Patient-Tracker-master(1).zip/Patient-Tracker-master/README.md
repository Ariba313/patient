# Patient-Tracker-APP

Our Web Application propose is to develop dispensary patient data management and viewing. The system is aimed to help doctors to enter as well as view patient history as well as other patient details. The system can be accessed on web to be used for furthe login. The application allows a doctor to open application and enter the details of any patient that used his service. The application allows doctor to insert various data fields regarding a patient including patient name, disease,medication provided, date of arrival etc. The system saves this patient related data in the realtime DB. The doctor may now view this data as and when needed. The doctor may check the details whenever needed. The application allows doctor to search patients by name, id as well as appointment date.

Doctor may enter details of any patient with related data.
The system saves this entry for later viewing.
The system allows doctor to view patient history as and when needed.
The application allows doctor to search any patient by name.
The application allows doctor to search patients by appointment date.
The application allows doctor to search patients by patient id.
